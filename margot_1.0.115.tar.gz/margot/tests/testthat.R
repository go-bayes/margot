# This file is part of the standard devtools workflow.
# See ?devtools::use_testthat() for more information.

library(testthat)
library(margot)

test_check("margot")