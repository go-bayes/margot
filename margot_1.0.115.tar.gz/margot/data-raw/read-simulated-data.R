# read data of six waves if needed
# url <- "https://www.dropbox.com/scl/fi/zzpdvwdz84luibzrjqk22/df_nz_six.rds?rlkey=1e85who7okxjeq1578mfa0d0o&dl=1"
# df <- readRDS(url(url))
